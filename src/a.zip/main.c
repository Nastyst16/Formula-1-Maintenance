#include "structs.h"

int compare_sensor_type(const void *a, const void *b) {
    const sensor *sensor_a = (const sensor*)a;
    const sensor *sensor_b = (const sensor*)b;

    if (sensor_a->sensor_type == TIRE &&
		sensor_b->sensor_type == PMU) {
        return -1;
    } else if (sensor_a->sensor_type == PMU &&
			   sensor_b->sensor_type == TIRE) {
        return 1;
    } else {
        return 0;
    }
}

int main(int argc, char const *argv[])
{
	int sensor_numbers;
	FILE *in = fopen(argv[1], "r");
	if (!in) {
		printf("Malloc failed\n");
		return 0;
	}

	fread(&sensor_numbers, sizeof(int), 1, in);

	sensor *sensor = malloc(sensor_numbers * sizeof(sensor));

	for (int i = 0; i < sensor_numbers; i++)
		sensor[i] = alloc_sensor(in);

	// sortare: punem pmu la inceputul vectorului
	// qsort(sensor, sensor_numbers, sizeof(sensor), compare_sensor_type);



	// char command[MAX_STRING_SIZE];

	// while (1) {
	// 	scanf("%s", command);

	// 	if (strcmp(command, "print") == 0) {
	// 		int index;
	// 		scanf("%d", &index);


	// 	} else if (strcmp(command, "analyze") == 0) {


	// 	} else if (strcmp(command, "clear") == 0) {


	// 	} else if (strcmp(command, "exit") == 0) {
	// 		// functie de frees
	// 		return 0;

	// 	} else {
	// 		printf("Invalid command\n");
	// 	}
	// }



	return 0;
}
